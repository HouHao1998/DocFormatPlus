package com.doc.format.util.excel;

import static com.doc.format.util.excel.ExcelToSettingsDataSource.settingsDataSource;

/**
 * <b>请输入名称</b>
 * <pre>
 * 描述<br/>
 * 作用：；<br/>
 * 限制：；<br/>
 * </pre>
 *
 * @author 侯浩(1272)
 * @date 2024/10/11 09:33
 */
public class StartMain {
    public static void main(String[] args) {
        String excelFilePath = "/Users/houhao/Downloads/审计Excel清单/绕行访问涉敏后台资源审计.xlsx";  // Excel文件路径
        String jsonFilePath = "/Users/houhao/Downloads/审计Excel清单/report_templates.json";  // JSON文件路径
        String sqlFilePath = "/Users/houhao/Downloads/审计Excel清单/settingsDataSource.txt";  // SQL脚本文件路径
        String folderPath = "/Users/houhao/Downloads/审计Excel清单/";
        String groupSn = "9902360002";
        String groupName = "审计报表数据源";
        long snCounter = 9902240908370004L;


        ExcelToSettingsDataSource.settingsDataSourceForFolder(folderPath, jsonFilePath, sqlFilePath, snCounter, groupSn, groupName);
        String outputFolder = "/Users/houhao/Downloads/审计Excel清单/上海报表测试文件夹/"; // 输出 Excel 文件夹路径

        ExcelReportGenerator.makeExcel(jsonFilePath, outputFolder);
        long fileSn = 5097652706810301L;
        String minIo = "/Users/houhao/Downloads/审计Excel清单/minIo.txt";
        GenerateSQLForFiles.excelToFileSql(minIo, fileSn, jsonFilePath, jsonFilePath, outputFolder);
        long templateSn = 80012409117101001L;  // 初始SN值
        String templateFilePath = "/Users/houhao/Downloads/审计Excel清单/report_template.txt";  // SQL文件路径

        ExcelToTemplate.excelToTemplate(templateFilePath, jsonFilePath, jsonFilePath, templateSn);
        long templateConfigSn = 80012409181190001L;  // 初始SN值
        String reportTemplateConfigFilePath = "/Users/houhao/Downloads/审计Excel清单/report_template_config.txt";
        ExcelToTemplateConfig.excelToTemplateConfig(reportTemplateConfigFilePath, jsonFilePath, templateConfigSn);
        long taskSn = 80042409112820011L;
        String outputFilePath = "/Users/houhao/Downloads/审计Excel清单/report_task.txt";  // SQL 文件输出路径

        ExcelToTask.jsonToTask(jsonFilePath, outputFilePath, taskSn);
    }


}
