package com.doc.format.util.excel;

/**
 * <b>请输入名称</b>
 * <pre>
 * 描述<br/>
 * 作用：；<br/>
 * 限制：；<br/>
 * </pre>
 *
 * @author 侯浩(1272)
 * @date 2024/9/11 14:53
 */

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.util.List;

public class ExcelToTemplateConfig {


    public static void main(String[] args) {
        String SQL_FILE_PATH = "/Users/houhao/Downloads/report_template_config脚本.txt";  // SQL文件路径
        String JSON_FILE_PATH = "/Users/houhao/Downloads/report_templates.json";  // JSON文件路径
        long snCounter = 80012409111190001L;  // 初始SN值
        excelToTemplateConfig(SQL_FILE_PATH, JSON_FILE_PATH, snCounter);
    }

    public static void excelToTemplateConfig(String SQL_FILE_PATH, String JSON_FILE_PATH, long snCounter) {
        try (BufferedWriter sqlWriter = new BufferedWriter(new FileWriter(SQL_FILE_PATH))) {
            // 读取并加载JSON文件
            List<ReportTemplate> reportTemplates = loadReportTemplates(JSON_FILE_PATH);

            for (ReportTemplate template : reportTemplates) {
                // 生成SQL语句
                String sql = generateSQL(template, snCounter);
                // 写入SQL到文件
                sqlWriter.write(sql);
                sqlWriter.newLine();

                // 输出到控制台
                System.out.println(sql);

                // 自增sn
                snCounter++;
            }

            System.out.println("SQL脚本已保存到: " + SQL_FILE_PATH);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 生成INSERT语句
    private static String generateSQL(ReportTemplate template, long snCounter) {
        String configJson = generateConfigJson(template);
        String tableHead = generateTableHead(template);
        String tableBody = generateTableBody(template);
        String tableField = generateTableField(template);

        return String.format("INSERT INTO `report_template_config` "
                        + "(`template_sn`, `dataset_codes`, `dataset_param`, `config_json`, `deleted`, `sn`, `table_head`, `table_body`, `template_file_sn`, `add_time`, `table_field`) "
                        + "VALUES (%d, NULL, NULL, '%s', 0, %d, '%s', '%s', %d, '2024-09-11 10:35:32', '%s');",
                template.getTemplateSn(), configJson, snCounter, tableHead, tableBody, template.getFileSn(), tableField);
    }

    // 生成config_json字段
    private static String generateConfigJson(ReportTemplate template) {
        StringBuilder configJson = new StringBuilder();

        // 构建 JSON 格式的外层结构
        configJson.append("{\"singleVars\":[],\"tables\":[{");

        // **处理 detail 层级**
        configJson.append("\"detail\":{");

        // 填写 detail 部分的 filterField
        configJson.append("\"filterField\":[{\"fieldComment\":\"组织编码\",\"fieldName\":\"orgCode\",\"fieldType\":\"String\",\"inputType\":\"CUSTOM\",\"option\":[],\"value\":\"\"}],");

        // 填写 datasetKey、datasetLabel、items 等信息
        configJson.append("\"datasetKey\":[\"9902330002\",\"")
                .append(template.getCode())
                .append("_detail\"],\"datasetLabel\":\"审计报表数据源/")
                .append(template.getName())
                .append("明细\",\"items\":\"students\",\"startCell\":\"A2\",\"lastCell\":\"E3\",");

        // 动态填充 detail 部分的 tableField
        configJson.append("\"tableField\":[");
        for (Field field : template.getDetailDataSource().getFields()) {
            configJson.append(String.format("{\"fieldName\":\"%s\",\"tableName\":\"%s\"},",
                    field.getFieldName(), field.getTableName()));
        }
        if (configJson.length() > 1) {
            configJson.setLength(configJson.length() - 1);  // 去掉最后的逗号
        }
        configJson.append("],");

        // 填写 detail 部分的 fieldsConfigs
        configJson.append("\"fieldsConfigs\":[");
        for (Field field : template.getDetailDataSource().getFields()) {
            configJson.append(String.format("{\"field\":\"%s\",\"templateVarName\":\"%s\",\"drilling\":\"0\",\"drillingConfig\":{}},",
                    field.getFieldName(), field.getFieldName()));
        }
        if (configJson.length() > 1) {
            configJson.setLength(configJson.length() - 1);  // 去掉最后的逗号
        }

        // 填写 detail 部分的 fieldoptions
        configJson.append("],\"fieldoptions\":[");
        for (Field field : template.getDetailDataSource().getFields()) {
            configJson.append(String.format("{\"comment\":\"%s\",\"dataType\":\"String\",\"dataTypeName\":\"字符串\",\"name\":\"%s\"},",
                    field.getTableName(), field.getFieldName()));
        }
        if (configJson.length() > 1) {
            configJson.setLength(configJson.length() - 1);  // 去掉最后的逗号
        }

        configJson.append("]},");  // 结束 detail 部分

        // **处理 stat 层级**
        configJson.append("\"stat\":{");

        // 填写 stat 部分的 filterField
        configJson.append("\"filterField\":[{\"fieldComment\":\"父组织编码\",\"fieldName\":\"parentOrgCode\",\"fieldType\":\"String\",\"inputType\":\"CUSTOM\",\"option\":[],\"value\":\"\"}],");

        // 填写 datasetKey、datasetLabel、items 等信息
        configJson.append("\"datasetKey\":[\"9902330002\",\"")
                .append(template.getCode())
                .append("_stat\"],\"datasetLabel\":\"审计报表数据源/")
                .append(template.getName())
                .append("统计\",\"items\":\"students\",\"startCell\":\"A2\",\"lastCell\":\"E3\",");

        // 动态填充 stat 部分的 tableField
        configJson.append("\"tableField\":[");
        for (Field field : template.getStatDataSource().getFields()) {
            configJson.append(String.format("{\"fieldName\":\"%s\",\"tableName\":\"%s\"},",
                    field.getFieldName(), field.getTableName()));
        }
        if (configJson.length() > 1) {
            configJson.setLength(configJson.length() - 1);  // 去掉最后的逗号
        }
        configJson.append("],");

        // 填写 stat 部分的 fieldsConfigs
        configJson.append("\"fieldsConfigs\":[");
        for (Field field : template.getStatDataSource().getFields()) {
            configJson.append(String.format("{\"field\":\"%s\",\"templateVarName\":\"%s\",\"drilling\":\"0\",\"drillingConfig\":{}},",
                    field.getFieldName(), field.getFieldName()));
        }
        if (configJson.length() > 1) {
            configJson.setLength(configJson.length() - 1);  // 去掉最后的逗号
        }

        // 填写 stat 部分的 fieldoptions
        configJson.append("],\"fieldoptions\":[");
        for (Field field : template.getStatDataSource().getFields()) {
            configJson.append(String.format("{\"comment\":\"%s\",\"dataType\":\"String\",\"dataTypeName\":\"字符串\",\"name\":\"%s\"},",
                    field.getTableName(), field.getFieldName()));
        }
        if (configJson.length() > 1) {
            configJson.setLength(configJson.length() - 1);  // 去掉最后的逗号
        }

        configJson.append("]}");  // 结束 stat 部分

        configJson.append("],\"charts\":[]}");  // 结束 tables 和 charts 部分

        return configJson.toString().replace("'", "\\'");  // 转义单引号
    }

    // 生成table_head字段
    private static String generateTableHead(ReportTemplate template) {
        StringBuilder tableHead = new StringBuilder("{");

        // **生成 detail 部分的表头**
        tableHead.append("\"detail\":\"[[");
        for (Field field : template.getDetailDataSource().getFields()) {
            tableHead.append(String.format("{\"t_h_title\":\"%s\"},", field.getTableName()));
        }
        if (tableHead.length() > 1) {
            tableHead.setLength(tableHead.length() - 1);  // 去掉最后的逗号
        }
        tableHead.append("]],");

        // **生成 stat 部分的表头**
        tableHead.append("\"stat\":\"[[");
        for (Field field : template.getStatDataSource().getFields()) {
            tableHead.append(String.format("{\"t_h_title\":\"%s\"},", field.getTableName()));
        }
        if (tableHead.length() > 1) {
            tableHead.setLength(tableHead.length() - 1);  // 去掉最后的逗号
        }
        tableHead.append("]]\"");

        tableHead.append("}");

        return tableHead.toString();
    }

    // 生成table_body字段
    private static String generateTableBody(ReportTemplate template) {
        StringBuilder tableBody = new StringBuilder("{");

        // **处理 detail 部分的表体**
        tableBody.append("\"detail\":\"[[");
        for (Field field : template.getDetailDataSource().getFields()) {
            tableBody.append(String.format("{\"drilling\":\"0\",\"field\":\"%s\",\"templateVarName\":\"%s\"},",
                    field.getFieldName(), field.getFieldName()));
        }
        if (tableBody.length() > 1) {
            tableBody.setLength(tableBody.length() - 1);  // 去掉最后的逗号
        }
        tableBody.append("]],");

        // **处理 stat 部分的表体**
        tableBody.append("\"stat\":\"[[");
        for (Field field : template.getStatDataSource().getFields()) {
            tableBody.append(String.format("{\"drilling\":\"0\",\"field\":\"%s\",\"templateVarName\":\"%s\"},",
                    field.getFieldName(), field.getFieldName()));
        }
        if (tableBody.length() > 1) {
            tableBody.setLength(tableBody.length() - 1);  // 去掉最后的逗号
        }
        tableBody.append("]]\"");

        tableBody.append("}");

        return tableBody.toString();
    }


    // 生成table_field字段
    private static String generateTableField(ReportTemplate template) {
        StringBuilder tableField = new StringBuilder("[");
        for (Field field : template.getFields()) {
            tableField.append(String.format("{\"audit\":%d,\"auditDimension\":%d,\"fieldName\":\"%s\",\"tableName\":\"%s\"},",
                    0, 0, field.getFieldName(), field.getTableName()));
        }
        if (tableField.length() > 1) {
            tableField.setLength(tableField.length() - 1);  // 去掉最后的逗号
        }
        tableField.append("]");
        return tableField.toString();
    }

    // 读取JSON文件并转换为ReportTemplate列表
    private static List<ReportTemplate> loadReportTemplates(String jsonFilePath) throws IOException {
        Gson gson = new Gson();
        try (Reader reader = new FileReader(jsonFilePath)) {
            Type listType = new TypeToken<List<ReportTemplate>>() {
            }.getType();
            return gson.fromJson(reader, listType);
        }
    }
}
